// This file contains all the mock data for the application.

import {
  User,
  Team,
  Objective,
  Project,
  Task,
  Strategy,
  Index,
  CompanyVision,
  KanbanColumn,
  Form,
  FormCategory,
  FormSubmission,
  Document,
  DocumentStatus,
  LearningAssignment,
  MicroLearning,
  YouTubeVideo,
  Book,
  FeedbackTag,
  KRType,
  KRCategory,
  LearningResourceType,
  LearningAssignmentStatus,
  DocumentBlock,
  Board,
  Process,
  Workspace,
  CustomerNeed,
  GeneralFeedback,
  Notification,
  CustomerNeedCategory,
} from './types';

const today = new Date();
const todayISO = new Date(Date.UTC(today.getFullYear(), today.getMonth(), today.getDate())).toISOString();

const getDateWithOffset = (days: number): string => {
    const date = new Date();
    date.setDate(date.getDate() - days);
    return new Date(Date.UTC(date.getFullYear(), date.getMonth(), date.getDate())).toISOString();
};

const tomorrow = new Date();
tomorrow.setDate(today.getDate() + 1);
const tomorrowISO = new Date(Date.UTC(tomorrow.getFullYear(), tomorrow.getMonth(), tomorrow.getDate())).toISOString();

export const MOCK_USERS: User[] = [
  { id: 'u-hotel-1', name: 'شهریار ریاحی', username: 'admin', password: 'admin', role: 'admin', teamId: 't-hotel-management', avatarUrl: 'https://i.pravatar.cc/150?u=shahriar' },
  { id: 'u-hotel-2', name: 'سارا رضایی', username: 'sara', password: 'password', role: 'lead', teamId: 't-hotel-marketing', avatarUrl: 'https://i.pravatar.cc/150?u=sara' },
  { id: 'u-hotel-3', name: 'علی کریمی', username: 'ali', password: 'password', role: 'member', teamId: 't-hotel-ops', avatarUrl: 'https://i.pravatar.cc/150?u=ali' },
];

export const MOCK_TEAMS: Team[] = [
    { id: 't-hotel-management', name: 'مدیریت', leadId: 'u-hotel-1', memberIds: ['u-hotel-1'], icon: 'UserGroupIcon', category: 'عمومی' },
    { id: 't-hotel-marketing', name: 'بازاریابی', leadId: 'u-hotel-2', memberIds: ['u-hotel-2'], icon: 'MegaphoneIcon', category: 'بازاریابی' },
    { id: 't-hotel-ops', name: 'عملیات', leadId: 'u-hotel-1', memberIds: ['u-hotel-3'], icon: 'SettingsIcon', category: 'فنی' },
];

export const MOCK_OBJECTIVES: Objective[] = [
    {
        id: 'obj-hotel-1',
        title: 'افزایش رضایت مهمانان',
        description: 'بهبود تجربه اقامت برای همه مهمانان و افزایش امتیازات آنلاین.',
        ownerId: 'u-hotel-1',
        category: 'CUSTOMER_MARKET',
        isArchived: false,
        keyResults: [
            { id: 'kr1', title: 'افزایش میانگین امتیاز از ۴.۲ به ۴.۵', ownerId: 'u-hotel-2', category: KRCategory.Standard, type: KRType.Number, startValue: 4.2, targetValue: 4.5, currentValue: 4.3, checkIns: [] },
            { id: 'kr2', title: 'کاهش شکایات مهمانان به میزان ۲۰٪', ownerId: 'u-hotel-3', category: KRCategory.Standard, type: KRType.Percentage, startValue: 10, targetValue: 8, currentValue: 9, checkIns: [] },
        ]
    }
];

export const MOCK_PROJECTS: Project[] = [
    { id: 'p-hotel-1', name: 'بهبود لابی هتل', objectiveId: 'obj-hotel-1', color: 'blue' },
    { id: 'p-hotel-2', name: 'کمپین بازاریابی تابستان', objectiveId: 'obj-hotel-1', color: 'green' }
];

export const MOCK_KANBAN_COLUMNS: KanbanColumn[] = [
  { id: 'todo', title: 'برای انجام', color: 'gray' },
  { id: 'in-progress', title: 'در حال پیشرفت', color: 'orange' },
  { id: 'done', title: 'انجام شد', color: 'green' },
];


export const MOCK_TASKS: Task[] = [
    { id: 't-hotel-1', content: 'خرید مبلمان جدید', columnId: 'todo', status: 'برای انجام', projectId: 'p-hotel-1', assigneeId: 'u-hotel-3', dueDate: tomorrowISO },
    { id: 't-hotel-2', content: 'طراحی بروشورهای جدید', columnId: 'in-progress', status: 'در حال پیشرفت', projectId: 'p-hotel-2', assigneeId: 'u-hotel-2', startDate: getDateWithOffset(-2) },
    { id: 't-hotel-3', content: 'آموزش پرسنل پذیرش', columnId: 'done', status: 'انجام شد', projectId: 'p-hotel-1', assigneeId: 'u-hotel-3', dueDate: getDateWithOffset(-1) },
];

export const MOCK_STRATEGIES: Strategy[] = [
    { id: 's-hotel-1', name: 'تجربه مشتری محور', description: 'تمرکز بر ایجاد یک تجربه به یاد ماندنی برای مهمانان', icon: 'HandshakeIcon', ownerIds: ['u-hotel-1'], category: 'محور ارزش‌آفرینی برای مشتری', status: 'در جریان' }
];

export const MOCK_INDICES: Index[] = [
    { id: 'i-hotel-1', name: 'امتیاز رضایت مشتری (CSAT)', category: 'Customer', icon: 'StarIcon', ownerIds: ['u-hotel-2'] }
];

export const MOCK_COMPANY_VISION: CompanyVision = {
    missionTitle: 'ارائه بهترین تجربه اقامتی در منطقه',
    passion: 'مهمان نوازی',
    skill: 'مدیریت هتل',
    market: 'گردشگران',
    business: 'اقامت و خدمات هتلداری'
};


export const MOCK_FORM_CATEGORIES: FormCategory[] = [
    { id: 'fc-1', title: 'منابع انسانی' },
    { id: 'fc-2', title: 'عملیات' },
];

export const MOCK_FORMS: Form[] = [
    { id: 'form-1', title: 'فرم نظرسنجی رضایت مهمان', description: 'جمع‌آوری بازخورد مهمانان پس از اقامت', categoryId: 'fc-2', fields: [], creatorId: 'u-hotel-1' }
];

export const MOCK_SUBMISSIONS: FormSubmission[] = [];

export const MOCK_DOCUMENT_STATUSES: DocumentStatus[] = [
  { id: 'ds-1', label: 'پیش‌نویس', color: 'bg-gray-500', textColor: 'text-white' },
  { id: 'ds-2', label: 'منتشر شده', color: 'bg-green-500', textColor: 'text-white' },
];

export const MOCK_DOCUMENTS: Document[] = [
    { id: 'doc-1', title: 'راهنمای پذیرش مهمانان VIP', icon: '📄', content: [], creatorId: 'u-hotel-1', createdAt: todayISO, lastUpdatedAt: todayISO, statusId: 'ds-2' }
];

export const MOCK_MICRO_LEARNINGS: MicroLearning[] = [
    { id: 'ml-1', topic: 'اصول ارائه بازخورد موثر', generatedText: '...', quiz: [] }
];
export const MOCK_YOUTUBE_VIDEOS: YouTubeVideo[] = [];
export const MOCK_BOOKS: Book[] = [];

export const MOCK_LEARNING_ASSIGNMENTS: LearningAssignment[] = [
    { id: 'la-1', assigneeId: 'u-hotel-3', assignerId: 'u-hotel-1', resourceId: 'ml-1', resourceType: LearningResourceType.MICRO_LEARNING, assignedAt: todayISO, status: LearningAssignmentStatus.ASSIGNED }
];

export const MOCK_FEEDBACK_TAGS: FeedbackTag[] = [
    { id: 'ft-1', name: 'کارت عالی بود', description: 'تشکر از عملکرد عالی', icon: 'TrophyIcon', color: '#f59e0b' }
];
export const MOCK_CHALLENGE_TAGS: FeedbackTag[] = [
    { id: 'ct-1', name: 'کمبود منابع', description: 'منابع کافی برای انجام کار وجود نداشت', icon: 'ExclamationTriangleIcon', color: '#ef4444' }
];

export const MOCK_BOARDS: Board[] = [
    { id: 'b-main', name: 'برد اصلی', projectId: 'all', defaultViewMode: 'board', isPinned: true, tableViewColumns: ['assigneeId', 'dueDate'] }
];

export const MOCK_PROCESSES: Process[] = [];
export const MOCK_WORKSPACES: Workspace[] = [
    { id: 'ws-hotel', name: 'هتل بزرگ', icon: 'BuildingOfficeIcon', color: 'blue', description: 'فضای کاری اصلی هتل', type: 'company', companyName: 'گروه هتل‌های زنجیره‌ای' }
];

export const MOCK_CUSTOMER_NEEDS: CustomerNeed[] = [
    { id: 'cn-1', description: 'اتاق تمیز و راحت', category: 'ESSENTIAL' }
];

export const MOCK_GENERAL_FEEDBACKS: GeneralFeedback[] = [];

export const MOCK_NOTIFICATIONS: Notification[] = [
    { id: 'n-1', title: 'وظیفه جدید برای شما', summary: 'وظیفه "خرید مبلمان جدید" به شما اختصاص داده شد.', timestamp: todayISO, isRead: false, type: 'task', itemId: 't-hotel-1', userId: 'u-hotel-3' },
    { id: 'n-2', title: 'یک نفر شما را منشن کرد', summary: 'سارا رضایی در دستورالعمل "راهنمای پذیرش" شما را منشن کرد.', timestamp: getDateWithOffset(-1), isRead: true, type: 'mention', itemId: 'doc-1', userId: 'u-hotel-1' },
];